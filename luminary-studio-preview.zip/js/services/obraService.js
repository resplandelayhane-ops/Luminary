/* ============================================================
   services/obraService.js
   ------------------------------------------------------------
   Every read/write to the 'obras' store goes through here —
   no other module touches db.js directly for obra data. This
   is the seam Phase 2+ (Bíblia da Obra, World Building, etc.)
   will hang their own services off, following the same pattern.
   ============================================================ */

import { db } from '../core/db.js';
import { uid } from '../utils/helpers.js';

const STORE = 'obras';

const BLANK_COUNTERS = { capitulos: 0, palavras: 0 };

function nowISO() {
  return new Date().toISOString();
}

export const obraService = {
  /** Creates a new, fully isolated obra. Nothing is copied from any other obra. */
  async create(fields) {
    const obra = {
      id: uid(),
      titulo: fields.titulo?.trim() || 'Obra sem título',
      subtitulo: fields.subtitulo?.trim() || '',
      autor: fields.autor?.trim() || '',
      idioma: fields.idioma || 'Português (Brasil)',
      genero: fields.genero || '',
      subgenero: fields.subgenero || '',
      faixaEtaria: fields.faixaEtaria || '',
      tipoNarrativa: fields.tipoNarrativa || '',
      tempoVerbal: fields.tempoVerbal || 'Passado',
      pessoaNarrativa: fields.pessoaNarrativa || 'Terceira pessoa',
      sinopse: fields.sinopse?.trim() || '',
      premissa: fields.premissa?.trim() || '',
      objetivo: fields.objetivo?.trim() || '',
      capitulosPrevistos: Number(fields.capitulosPrevistos) || 0,
      palavrasPorCapitulo: Number(fields.palavrasPorCapitulo) || 0,
      status: fields.status || 'Planejamento',
      tags: fields.tags || [],
      categoria: fields.categoria || '',
      capa: fields.capa || null,
      favorito: false,
      arquivada: false,
      excluida: false,
      dataCriacao: nowISO(),
      ultimaModificacao: nowISO(),
      contadores: { ...BLANK_COUNTERS },
    };
    await db.put(STORE, obra);
    return obra;
  },

  async update(id, patch) {
    const existing = await db.get(STORE, id);
    if (!existing) throw new Error('Obra não encontrada.');
    const updated = { ...existing, ...patch, id, ultimaModificacao: nowISO() };
    await db.put(STORE, updated);
    return updated;
  },

  async get(id) {
    return db.get(STORE, id);
  },

  /** Lists obras, excluding soft-deleted ones unless explicitly requested. */
  async listAll({ includeExcluded = false } = {}) {
    const all = await db.getAll(STORE);
    return includeExcluded ? all : all.filter((o) => !o.excluida);
  },

  async listFavoritas() {
    const all = await this.listAll();
    return all.filter((o) => o.favorito && !o.arquivada);
  },

  async listArquivadas() {
    const all = await this.listAll();
    return all.filter((o) => o.arquivada);
  },

  async listLixeira() {
    return this.listAll({ includeExcluded: true }).then((all) => all.filter((o) => o.excluida));
  },

  async toggleFavorito(id) {
    const o = await db.get(STORE, id);
    return this.update(id, { favorito: !o.favorito });
  },

  async toggleArquivada(id) {
    const o = await db.get(STORE, id);
    return this.update(id, { arquivada: !o.arquivada });
  },

  async moveToTrash(id) {
    return this.update(id, { excluida: true, dataExclusao: nowISO() });
  },

  async restoreFromTrash(id) {
    return this.update(id, { excluida: false, dataExclusao: null });
  },

  async permanentDelete(id) {
    return db.delete(STORE, id);
  },

  /** 0-100 progress based on chapters written vs. planned. */
  progress(obra) {
    if (!obra.capitulosPrevistos) return 0;
    return Math.min(100, Math.round((obra.contadores.capitulos / obra.capitulosPrevistos) * 100));
  },
};
