/* ============================================================
   main.js — bootstrap
   ============================================================ */

import { router } from './core/router.js';
import { appState } from './core/state.js';
import { mountLanding } from './components/landing.js';
import { mountHeader } from './components/header.js';
import { mountSidebar } from './components/sidebar.js';
import { renderGaveta } from './components/gaveta.js';
import { renderDashboard } from './components/dashboard.js';
import { renderConfiguracoes } from './components/configuracoes.js';
import { renderBackup } from './components/backup.js';
import { renderPlaceholder } from './components/placeholder.js';
import { openNovaObraWizard } from './components/obraWizard.js';
import { mountParticles } from './utils/particles.js';

async function boot() {
  const mainEl = document.getElementById('lum-main');

  await mountHeader();
  mountSidebar({ onNovaObra: openWizard });
  document.addEventListener('lum:nova-obra', openWizard);

  registerRoutes(mainEl);

  mountLanding({
    onEnter: () => {
      const app = document.getElementById('lum-app');
      app.classList.add('lum-app--visible');
      mountParticles(document.getElementById('lum-particles-ambient'), { density: 'low' });
      router.start();
    },
  });
}

function openWizard() {
  openNovaObraWizard({
    onCreated: () => {}, // wizard already navigates to the new obra's dashboard
  });
}

function registerRoutes(mainEl) {
  router.register('gaveta', () => renderGaveta(mainEl, 'all'));
  router.register('favoritos', () => renderGaveta(mainEl, 'favoritos'));
  router.register('arquivadas', () => renderGaveta(mainEl, 'arquivadas'));
  router.register('lixeira', () => renderGaveta(mainEl, 'lixeira'));
  router.register('dashboard/:id', ({ id }) => renderDashboard(mainEl, id));
  router.register('configuracoes', () => renderConfiguracoes(mainEl));
  router.register('backup', () => renderBackup(mainEl));
  router.register('em-breve/:modulo', ({ modulo }) => renderPlaceholder(mainEl, modulo));
}

boot();
