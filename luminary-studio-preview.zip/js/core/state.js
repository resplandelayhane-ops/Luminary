/* ============================================================
   core/state.js — minimal pub/sub app state
   ------------------------------------------------------------
   Deliberately not a framework. At this scope (shell + obra
   CRUD) a ~40-line observable is enough and keeps the bundle
   dependency-free, which matters since this ships as static
   files with no build step.
   ============================================================ */

const listeners = new Map(); // key -> Set<fn>

const state = {
  obraAtiva: null,       // full obra object, or null when on the library/dashboard shell
  sidebarCollapsed: false,
  sidebarDrawerOpen: false, // mobile only
  view: 'gaveta',          // current route id
};

function get(key) {
  return state[key];
}

function set(key, value) {
  state[key] = value;
  const set_ = listeners.get(key);
  if (set_) set_.forEach((fn) => fn(value));
}

function subscribe(key, fn) {
  if (!listeners.has(key)) listeners.set(key, new Set());
  listeners.get(key).add(fn);
  return () => listeners.get(key).delete(fn);
}

export const appState = { get, set, subscribe };
