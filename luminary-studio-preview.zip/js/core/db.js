/* ============================================================
   core/db.js — IndexedDB wrapper for Luminary Studio AI
   ------------------------------------------------------------
   Why IndexedDB and not localStorage: a single saga with 40
   chapters + full character bible + version history blows past
   localStorage's ~5-10MB ceiling fast. IndexedDB has no such
   practical limit and still works with zero backend, which is
   required since this ships as a static site (GitHub Pages /
   Cloudflare Pages) with no server.

   All object stores for future modules (Parts 2-6 of the spec)
   are declared here now, even though only 'obras' and 'config'
   have UI in this first build. Declaring them upfront avoids a
   breaking IndexedDB version-upgrade migration later, when a
   client's obra library may already contain real data.
   ============================================================ */

const DB_NAME = 'luminary_studio_db';
const DB_VERSION = 1;

const SCHEMA = [
  { name: 'config', keyPath: 'key', indexes: [] },
  { name: 'obras', keyPath: 'id', indexes: [
    { name: 'favorito', keyPath: 'favorito' },
    { name: 'arquivada', keyPath: 'arquivada' },
    { name: 'status', keyPath: 'status' },
    { name: 'ultimaModificacao', keyPath: 'ultimaModificacao' },
  ] },
  // Reserved for later phases (Bíblia da Obra / World Building / Gerador de Capítulos):
  { name: 'personagens', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'lugares', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'objetos', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'faccoes', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'capitulos', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }, { name: 'numero', keyPath: 'numero' }] },
  { name: 'resumos', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'cronologia', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
  { name: 'worldbuilding', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }, { name: 'tipo', keyPath: 'tipo' }] },
  { name: 'backups', keyPath: 'id', indexes: [{ name: 'obraId', keyPath: 'obraId' }] },
];

let _dbPromise = null;

function openDB() {
  if (_dbPromise) return _dbPromise;
  _dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (event) => {
      const db = event.target.result;
      SCHEMA.forEach((storeDef) => {
        if (db.objectStoreNames.contains(storeDef.name)) return;
        const store = db.createObjectStore(storeDef.name, { keyPath: storeDef.keyPath });
        storeDef.indexes.forEach((idx) => {
          store.createIndex(idx.name, idx.keyPath, { unique: false });
        });
      });
    };

    req.onsuccess = (event) => resolve(event.target.result);
    req.onerror = (event) => reject(event.target.error);
    req.onblocked = () => reject(new Error('Banco de dados bloqueado por outra aba aberta.'));
  });
  return _dbPromise;
}

function tx(storeName, mode) {
  return openDB().then((db) => db.transaction(storeName, mode).objectStore(storeName));
}

export const db = {
  /** Fetch a single record by primary key. Resolves null if not found. */
  async get(storeName, key) {
    const store = await tx(storeName, 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => reject(req.error);
    });
  },

  /** Fetch all records, optionally filtered by an index equality match. */
  async getAll(storeName, indexName, indexValue) {
    const store = await tx(storeName, 'readonly');
    return new Promise((resolve, reject) => {
      const source = indexName ? store.index(indexName) : store;
      const req = indexValue !== undefined ? source.getAll(indexValue) : source.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => reject(req.error);
    });
  },

  /** Insert or replace a record. The object must already contain its keyPath field. */
  async put(storeName, value) {
    const store = await tx(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(value);
      req.onsuccess = () => resolve(value);
      req.onerror = () => reject(req.error);
    });
  },

  async delete(storeName, key) {
    const store = await tx(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  },

  async clear(storeName) {
    const store = await tx(storeName, 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.clear();
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  },

  async count(storeName, indexName, indexValue) {
    const store = await tx(storeName, 'readonly');
    return new Promise((resolve, reject) => {
      const source = indexName ? store.index(indexName) : store;
      const req = indexValue !== undefined ? source.count(indexValue) : source.count();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  },
};
