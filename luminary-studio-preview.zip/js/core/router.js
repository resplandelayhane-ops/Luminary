/* ============================================================
   core/router.js — hash router
   ------------------------------------------------------------
   Static-site friendly: '#/gaveta', '#/dashboard/:id', etc.
   work with zero server config on GitHub Pages / Cloudflare
   Pages, unlike history-API routing which needs a rewrite rule.
   ============================================================ */

const routes = new Map(); // pattern -> handler(params)

function register(pattern, handler) {
  routes.set(pattern, handler);
}

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, '');
  const [path, query] = raw.split('?');
  const segments = path.split('/').filter(Boolean);
  return { segments, query: new URLSearchParams(query || '') };
}

function matchRoute(segments) {
  for (const [pattern, handler] of routes) {
    const patternSegments = pattern.split('/').filter(Boolean);
    if (patternSegments.length !== segments.length) continue;
    const params = {};
    let matched = true;
    for (let i = 0; i < patternSegments.length; i++) {
      const p = patternSegments[i];
      if (p.startsWith(':')) {
        params[p.slice(1)] = segments[i];
      } else if (p !== segments[i]) {
        matched = false;
        break;
      }
    }
    if (matched) return { handler, params };
  }
  return null;
}

function resolve() {
  const { segments, query } = parseHash();
  const match = matchRoute(segments.length ? segments : ['gaveta']);
  if (match) {
    match.handler({ ...match.params, query });
  } else {
    routes.get('gaveta')?.({});
  }
}

function navigate(path) {
  location.hash = path.startsWith('/') ? path : `/${path}`;
}

function start() {
  window.addEventListener('hashchange', resolve);
  resolve();
}

export const router = { register, navigate, start };
