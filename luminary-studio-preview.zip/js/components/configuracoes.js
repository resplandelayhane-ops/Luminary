/* ============================================================
   components/configuracoes.js
   ============================================================ */

import { db } from '../core/db.js';
import { appState } from '../core/state.js';
import { router } from '../core/router.js';
import { toast } from '../utils/feedback.js';
import { confirmDialog } from './modal.js';

export async function renderConfiguracoes(container) {
  appState.set('view', 'configuracoes');
  const apiKeys = (await db.get('config', 'apiKeys'))?.value || {};
  const providerLabels = { gemini: 'Google Gemini', openai: 'OpenAI', anthropic: 'Anthropic Claude', outro: 'Outro provedor' };

  let storageInfo = '';
  if (navigator.storage?.estimate) {
    const est = await navigator.storage.estimate();
    const usedMB = (est.usage / (1024 * 1024)).toFixed(1);
    storageInfo = `${usedMB} MB usados neste navegador`;
  }

  container.innerHTML = `
    <div class="lum-view">
      <div class="lum-view__header">
        <div>
          <h1 class="lum-view__title">Configurações</h1>
          <p class="lum-view__subtitle">Preferências deste navegador — nada aqui sai do seu dispositivo.</p>
        </div>
      </div>

      <div class="lum-card lum-corners" style="margin-bottom:var(--sp-5);">
        <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);">Chaves de API cadastradas</h3>
        ${Object.keys(apiKeys).length === 0
          ? `<p style="color:var(--lum-cream-faint);font-size:13.5px;">Nenhuma chave salva ainda. Cole uma no campo do cabeçalho.</p>`
          : Object.entries(apiKeys).map(([provider, info]) => `
              <div style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--lum-graphite-border);font-size:13.5px;">
                <span>${providerLabels[provider] || provider}</span>
                <span style="color:var(--lum-cream-faint);">•••• ${info.key.slice(-4)}</span>
              </div>
            `).join('')}
        <p style="font-size:11px;color:var(--lum-cream-faint);margin-top:var(--sp-3);">Chaves ficam só neste navegador (IndexedDB local). Nunca são enviadas pra nenhum servidor além do próprio provedor de IA quando você gera algo.</p>
      </div>

      <div class="lum-card lum-corners" style="margin-bottom:var(--sp-5);">
        <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);">Armazenamento</h3>
        <p style="color:var(--lum-cream-dim);font-size:13.5px;">${storageInfo || 'Estimativa indisponível neste navegador.'}</p>
        <p style="font-size:12px;color:var(--lum-cream-faint);margin-top:var(--sp-2);">Recomendado: exporte um <a href="#/backup">backup</a> regularmente.</p>
      </div>

      <div class="lum-card lum-corners" style="border-color:rgba(178,69,61,0.3);">
        <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);color:var(--lum-red-error);">Zona de risco</h3>
        <p style="color:var(--lum-cream-dim);font-size:13.5px;margin-bottom:var(--sp-4);">Apaga todas as obras e configurações deste navegador. Sem volta, a menos que você tenha um backup exportado.</p>
        <button class="lum-btn lum-btn--danger" id="lum-wipe-btn">Apagar todos os dados locais</button>
      </div>
    </div>
  `;

  container.querySelector('#lum-wipe-btn').addEventListener('click', async () => {
    const ok = await confirmDialog({
      title: 'Apagar tudo?',
      message: 'Isso remove permanentemente todas as obras, chaves e configurações salvas neste navegador.',
      confirmLabel: 'Apagar tudo',
      danger: true,
    });
    if (!ok) return;
    indexedDB.deleteDatabase('luminary_studio_db');
    toast('Dados apagados. Recarregando…');
    setTimeout(() => location.reload(), 1000);
  });
}
