/* ============================================================
   components/placeholder.js
   ============================================================ */

const MODULE_NAMES = {
  capitulos: 'Gerador de Capítulos',
  worldbuilding: 'Worldbuilding',
  personagens: 'Personagens',
  cronologia: 'Cronologia',
  biblioteca: 'Biblioteca',
  capas: 'Gerador de Capas',
  ia: 'Gerenciador de IA',
  backup: 'Backup',
  ajuda: 'Ajuda',
};

export function renderPlaceholder(container, moduleId) {
  const name = MODULE_NAMES[moduleId] || 'Este módulo';
  container.innerHTML = `
    <div class="lum-view">
      <div class="lum-soon lum-card lum-corners">
        <span class="lum-eyebrow">Em construção</span>
        <h2>${name}</h2>
        <p>Este módulo entra numa próxima etapa da construção. A base da obra (dados, navegação, biblioteca) já está pronta para receber ele sem retrabalho.</p>
      </div>
    </div>
  `;
}
