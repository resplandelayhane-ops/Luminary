/* ============================================================
   components/sidebar.js
   ------------------------------------------------------------
   Items marked `soon: true` route to the honest "em construção"
   placeholder (js/components/placeholder.js) instead of faking
   a working module. Nothing here pretends to be finished.
   ============================================================ */

import { appState } from '../core/state.js';
import { router } from '../core/router.js';
import { icon } from '../utils/icons.js';

const SECTIONS = [
  {
    label: 'Principal',
    items: [
      { id: 'gaveta', label: 'Obras', icon: 'books', route: '/gaveta' },
      { id: 'nova-obra', label: 'Nova Obra', icon: 'plus', action: 'nova-obra' },
    ],
  },
  {
    label: 'Obra Atual',
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: 'dashboard', route: null },
      { id: 'capitulos', label: 'Capítulos', icon: 'chapters', route: '/em-breve/capitulos' },
      { id: 'worldbuilding', label: 'Worldbuilding', icon: 'globe', route: '/em-breve/worldbuilding' },
      { id: 'personagens', label: 'Personagens', icon: 'users', route: '/em-breve/personagens' },
      { id: 'cronologia', label: 'Cronologia', icon: 'clock', route: '/em-breve/cronologia' },
    ],
  },
  {
    label: 'Estúdio',
    items: [
      { id: 'biblioteca', label: 'Biblioteca', icon: 'library', route: '/em-breve/biblioteca' },
      { id: 'capas', label: 'Capas', icon: 'image', route: '/em-breve/capas' },
      { id: 'ia', label: 'IA', icon: 'spark', route: '/em-breve/ia' },
    ],
  },
  {
    label: 'Sistema',
    items: [
      { id: 'favoritos', label: 'Favoritos', icon: 'star', route: '/favoritos' },
      { id: 'arquivadas', label: 'Arquivadas', icon: 'archive', route: '/arquivadas' },
      { id: 'backup', label: 'Backup', icon: 'cloud', route: '/backup' },
      { id: 'lixeira', label: 'Lixeira', icon: 'trash', route: '/lixeira' },
      { id: 'configuracoes', label: 'Configurações', icon: 'settings', route: '/configuracoes' },
      { id: 'ajuda', label: 'Ajuda', icon: 'help', route: '/em-breve/ajuda' },
    ],
  },
];

export function mountSidebar({ onNovaObra }) {
  const sidebar = document.getElementById('lum-sidebar');
  const overlay = document.getElementById('lum-sidebar-overlay');

  sidebar.innerHTML = `
    <div class="lum-sidebar__collapse-toggle">
      <button id="lum-collapse-btn" aria-label="Recolher menu">${icon('chevronLeft', { size: 16 })}</button>
    </div>
    <ul class="lum-nav">
      ${SECTIONS.map((section) => `
        <li class="lum-nav__section-label">${section.label}</li>
        ${section.items.map((item) => `
          <li class="lum-nav__item" data-nav-id="${item.id}" tabindex="0">
            ${icon(item.icon, { size: 17 })}
            <span>${item.label}</span>
          </li>
        `).join('')}
      `).join('')}
    </ul>
    <div class="lum-sidebar__footer" id="lum-sidebar-footer"></div>
  `;

  // Click / keyboard activation for nav items
  sidebar.querySelectorAll('[data-nav-id]').forEach((el) => {
    const activate = () => handleNavClick(el.dataset.navId, onNovaObra);
    el.addEventListener('click', activate);
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter') activate(); });
  });

  document.getElementById('lum-collapse-btn').addEventListener('click', () => {
    appState.set('sidebarCollapsed', !appState.get('sidebarCollapsed'));
  });

  appState.subscribe('sidebarCollapsed', (collapsed) => {
    sidebar.classList.toggle('lum-sidebar--collapsed', collapsed);
    document.getElementById('lum-app').classList.toggle('lum-sidebar-collapsed', collapsed);
    const btn = document.getElementById('lum-collapse-btn');
    if (btn) btn.innerHTML = icon(collapsed ? 'chevronRight' : 'chevronLeft', { size: 16 });
  });

  appState.subscribe('sidebarDrawerOpen', (open) => {
    sidebar.classList.toggle('lum-sidebar--drawer-open', open);
    overlay.classList.toggle('lum-open', open);
  });

  overlay.addEventListener('click', () => appState.set('sidebarDrawerOpen', false));

  appState.subscribe('obraAtiva', (obra) => renderFooter(obra));
  appState.subscribe('view', (view) => highlightActive(view));

  renderFooter(appState.get('obraAtiva'));
}

function renderFooter(obra) {
  const footer = document.getElementById('lum-sidebar-footer');
  if (!footer) return;
  footer.innerHTML = obra
    ? `<div class="lum-sidebar__obra-atual"><strong>${escapeAttr(obra.titulo)}</strong>${obra.autor || 'sem autor definido'}</div>`
    : `<div class="lum-sidebar__obra-atual">Nenhuma obra aberta</div>`;
}

function highlightActive(view) {
  document.querySelectorAll('.lum-nav__item').forEach((el) => {
    el.classList.toggle('lum-nav__item--active', el.dataset.navId === view);
  });
}

function handleNavClick(id, onNovaObra) {
  // Close the drawer on mobile as soon as a destination is chosen.
  appState.set('sidebarDrawerOpen', false);

  if (id === 'nova-obra') { onNovaObra(); return; }

  if (id === 'dashboard') {
    const obra = appState.get('obraAtiva');
    router.navigate(obra ? `/dashboard/${obra.id}` : '/gaveta');
    return;
  }

  const section = SECTIONS.flatMap((s) => s.items).find((i) => i.id === id);
  if (section?.route) router.navigate(section.route);
}

function escapeAttr(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}
