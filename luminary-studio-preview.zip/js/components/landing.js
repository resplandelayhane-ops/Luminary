/* ============================================================
   components/landing.js
   ============================================================ */

import { mountParticles } from '../utils/particles.js';

export function mountLanding({ onEnter }) {
  const landing = document.getElementById('lum-landing');
  const canvas = document.getElementById('lum-particles-landing');
  const particles = mountParticles(canvas, { density: 'landing' });

  const enterBtn = document.getElementById('lum-btn-enter');
  enterBtn.addEventListener('click', () => {
    landing.classList.add('lum-landing--leaving');
    setTimeout(() => {
      particles.stop();
      landing.remove();
      onEnter();
    }, 900);
  }, { once: true });

  // Allow entering with Enter/Space for keyboard users without hunting for the button.
  document.addEventListener('keydown', function onKey(e) {
    if ((e.key === 'Enter' || e.key === ' ') && document.body.contains(landing)) {
      e.preventDefault();
      enterBtn.click();
      document.removeEventListener('keydown', onKey);
    }
  });
}
