/* ============================================================
   components/dashboard.js
   ============================================================ */

import { obraService } from '../services/obraService.js';
import { db } from '../core/db.js';
import { appState } from '../core/state.js';
import { router } from '../core/router.js';
import { icon } from '../utils/icons.js';
import { formatNumber, formatRelative, escapeHtml } from '../utils/helpers.js';
import { openNovaObraWizard } from './obraWizard.js';
import { toast } from '../utils/feedback.js';

export async function renderDashboard(container, obraId) {
  const obra = await obraService.get(obraId);
  if (!obra) {
    container.innerHTML = `
      <div class="lum-view">
        <div class="lum-empty lum-card lum-corners">
          <h3>Obra não encontrada</h3>
          <p>Ela pode ter sido movida para a lixeira ou excluída.</p>
          <button class="lum-btn lum-btn--primary" id="lum-back-gaveta">Voltar pra Gaveta</button>
        </div>
      </div>
    `;
    container.querySelector('#lum-back-gaveta').addEventListener('click', () => router.navigate('/gaveta'));
    return;
  }

  appState.set('obraAtiva', obra);
  appState.set('view', 'dashboard');

  const [personagens, lugares, faccoes] = await Promise.all([
    db.getAll('personagens', 'obraId', obraId),
    db.getAll('lugares', 'obraId', obraId),
    db.getAll('faccoes', 'obraId', obraId),
  ]);

  const progress = obraService.progress(obra);

  container.innerHTML = `
    <div class="lum-view">
      <div class="lum-view__header">
        <div>
          <span class="lum-eyebrow">${escapeHtml(obra.genero || 'Sem gênero')} · <span class="lum-badge lum-badge--${badgeClass(obra.status)}" style="margin-left:4px;">${escapeHtml(obra.status)}</span></span>
          <h1 class="lum-view__title" style="margin-top:6px;">${escapeHtml(obra.titulo)}</h1>
          ${obra.subtitulo ? `<p class="lum-view__subtitle">${escapeHtml(obra.subtitulo)}</p>` : ''}
        </div>
        <div style="display:flex;gap:8px;">
          <button class="lum-btn lum-btn--ghost" id="lum-btn-editar">${icon('edit', { size: 14 })} Editar</button>
          <button class="lum-btn lum-btn--primary" id="lum-btn-escrever">${icon('chapters', { size: 15 })} Ir para Capítulos</button>
        </div>
      </div>

      <div class="lum-stats-grid">
        ${statCard('Capítulos', `${formatNumber(obra.contadores.capitulos)}${obra.capitulosPrevistos ? ` / ${formatNumber(obra.capitulosPrevistos)}` : ''}`, `${progress}% concluído`)}
        ${statCard('Palavras', formatNumber(obra.contadores.palavras), obra.palavrasPorCapitulo ? `~${formatNumber(obra.palavrasPorCapitulo)} por capítulo` : '')}
        ${statCard('Última edição', formatRelative(obra.ultimaModificacao), '')}
        ${statCard('Progresso', `${progress}%`, '')}
      </div>

      <div class="lum-panel-grid">
        <div class="lum-card lum-corners">
          <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-2);">Últimos Acontecimentos</h3>
          <div class="lum-empty" style="padding:var(--sp-6) var(--sp-3);">
            ${icon('clock', { size: 30 })}
            <p style="margin:0;">A cronologia se preenche sozinha assim que o primeiro capítulo for escrito.</p>
          </div>
          <hr class="lum-hairline" style="margin:var(--sp-4) 0;" />
          <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);">Objetivo da História</h3>
          <p style="font-family:var(--lum-font-body);color:var(--lum-cream-dim);line-height:1.7;font-size:14.5px;">
            ${obra.objetivo ? escapeHtml(obra.objetivo) : '<em style="color:var(--lum-cream-faint)">Nenhum objetivo definido ainda — edite a obra pra adicionar.</em>'}
          </p>
        </div>

        <div style="display:flex;flex-direction:column;gap:var(--sp-4);">
          <div class="lum-card lum-corners">
            <h3 style="font-family:var(--lum-font-heading);font-size:15px;margin-bottom:var(--sp-3);">Universo da Obra</h3>
            ${miniStat('Personagens', personagens.length)}
            ${miniStat('Lugares', lugares.length)}
            ${miniStat('Facções', faccoes.length)}
            <p style="font-size:11px;color:var(--lum-cream-faint);margin-top:var(--sp-3);">Esses módulos entram numa próxima etapa da construção.</p>
          </div>
          <div class="lum-card lum-corners">
            <h3 style="font-family:var(--lum-font-heading);font-size:15px;margin-bottom:var(--sp-2);">Sinopse</h3>
            <p style="font-family:var(--lum-font-body);color:var(--lum-cream-dim);font-size:13.5px;line-height:1.7;">
              ${obra.sinopse ? escapeHtml(obra.sinopse) : '<em style="color:var(--lum-cream-faint)">Sem sinopse ainda.</em>'}
            </p>
          </div>
        </div>
      </div>
    </div>
  `;

  container.querySelector('#lum-btn-editar').addEventListener('click', () => {
    openNovaObraWizard({
      obra,
      onSaved: () => renderDashboard(container, obraId),
    });
  });

  container.querySelector('#lum-btn-escrever').addEventListener('click', () => {
    router.navigate('/em-breve/capitulos');
  });
}

function statCard(label, value, hint) {
  return `
    <div class="lum-card lum-stat-card lum-corners">
      <div class="lum-stat-card__label">${label}</div>
      <div class="lum-stat-card__value">${value}</div>
      ${hint ? `<div class="lum-stat-card__hint">${hint}</div>` : ''}
    </div>
  `;
}

function miniStat(label, value) {
  return `
    <div style="display:flex;justify-content:space-between;padding:6px 0;font-size:13px;border-bottom:1px solid var(--lum-graphite-border);">
      <span style="color:var(--lum-cream-dim);">${label}</span>
      <span style="color:var(--lum-gold-antique);font-family:var(--lum-font-heading);">${value}</span>
    </div>
  `;
}

function badgeClass(status) {
  if (status === 'Planejamento') return 'planning';
  if (status === 'Revisão') return 'review';
  if (status === 'Finalizada') return 'done';
  return '';
}
