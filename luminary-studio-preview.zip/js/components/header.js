/* ============================================================
   components/header.js
   ------------------------------------------------------------
   Phase-1 note on the AI key field: this is the minimal single
   -key version required by Part 1 (selector + field + save).
   The full multi-key "Gerenciador de IA" (multiple named keys,
   status, quota, last-used, per Prompt 2) is a later phase and
   will read/write the same 'config' store key, so this doesn't
   get thrown away — just extended.
   ============================================================ */

import { db } from '../core/db.js';
import { appState } from '../core/state.js';
import { router } from '../core/router.js';
import { obraService } from '../services/obraService.js';
import { toast } from '../utils/feedback.js';
import { debounce, escapeHtml } from '../utils/helpers.js';
import { icon } from '../utils/icons.js';

const PROVIDERS = [
  { value: 'gemini', label: 'Google Gemini' },
  { value: 'openai', label: 'OpenAI' },
  { value: 'anthropic', label: 'Anthropic Claude' },
  { value: 'outro', label: 'Outro provedor' },
];

export async function mountHeader() {
  const header = document.getElementById('lum-header');
  header.innerHTML = `
    <button class="lum-header__menu-toggle lum-icon-btn" id="lum-menu-toggle" aria-label="Abrir menu">
      ${icon('menu')}
    </button>
    <div class="lum-header__brand">
      ${icon('mark')}
      <span>Luminary Studio AI</span>
    </div>
    <div class="lum-header__search">
      ${icon('search')}
      <input type="text" id="lum-global-search" placeholder="Buscar obras, personagens, capítulos…" autocomplete="off" />
      <div class="lum-header__search-results" id="lum-search-results"></div>
    </div>
    <div class="lum-header__spacer"></div>
    <div class="lum-header__actions">
      <div class="lum-header__ai-cluster" id="lum-ai-cluster">
        <select class="lum-select" id="lum-ai-provider">
          ${PROVIDERS.map((p) => `<option value="${p.value}">${p.label}</option>`).join('')}
        </select>
        <input type="password" class="lum-key-input" id="lum-ai-key" placeholder="Chave de API" />
        <button class="lum-icon-btn" id="lum-save-key" aria-label="Salvar chave" title="Salvar chave de API">
          ${icon('save')}
          <span class="lum-key-status" id="lum-key-status"></span>
        </button>
      </div>
      <button class="lum-icon-btn lum-header__ai-toggle" id="lum-ai-toggle" aria-label="Configurar chave de IA" title="Chave de IA">
        ${icon('spark')}
        <span class="lum-key-status" id="lum-key-status-mobile"></span>
      </button>
      <button class="lum-icon-btn" id="lum-btn-settings" aria-label="Configurações" title="Configurações">
        ${icon('settings')}
      </button>
    </div>
  `;

  await wireApiKey();
  wireSearch();

  document.getElementById('lum-menu-toggle').addEventListener('click', () => {
    appState.set('sidebarDrawerOpen', !appState.get('sidebarDrawerOpen'));
  });

  document.getElementById('lum-btn-settings').addEventListener('click', () => {
    router.navigate('/configuracoes');
  });
}

async function wireApiKey() {
  const providerSel = document.getElementById('lum-ai-provider');
  const keyInput = document.getElementById('lum-ai-key');
  const statusDot = document.getElementById('lum-key-status');
  const statusDotMobile = document.getElementById('lum-key-status-mobile');
  const saveBtn = document.getElementById('lum-save-key');
  const cluster = document.getElementById('lum-ai-cluster');
  const toggleBtn = document.getElementById('lum-ai-toggle');

  const saved = await db.get('config', 'apiKeys');
  const stored = saved?.value || {};

  function refreshForProvider() {
    const p = providerSel.value;
    keyInput.value = stored[p]?.key || '';
    updateStatusDot();
  }

  function updateStatusDot() {
    const hasAny = Object.values(stored).some((v) => v?.key);
    const cls = `lum-key-status ${hasAny ? 'lum-key-status--ok' : 'lum-key-status--missing'}`;
    statusDot.className = cls;
    statusDotMobile.className = cls;
  }

  providerSel.addEventListener('change', refreshForProvider);

  toggleBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    cluster.classList.toggle('lum-open');
  });
  document.addEventListener('click', (e) => {
    if (cluster.classList.contains('lum-open') && !cluster.contains(e.target) && e.target !== toggleBtn) {
      cluster.classList.remove('lum-open');
    }
  });

  saveBtn.addEventListener('click', async () => {
    const p = providerSel.value;
    const key = keyInput.value.trim();
    if (!key) {
      toast('Cole uma chave antes de salvar.', { type: 'error' });
      return;
    }
    stored[p] = { key, savedAt: new Date().toISOString() };
    // Stored locally only (IndexedDB, this browser) — never sent anywhere,
    // never hardcoded in source. Each writer/client enters their own key.
    await db.put('config', { key: 'apiKeys', value: stored });
    updateStatusDot();
    toast('Chave salva neste navegador.');
    cluster.classList.remove('lum-open');
  });

  refreshForProvider();
}

function wireSearch() {
  const input = document.getElementById('lum-global-search');
  const results = document.getElementById('lum-search-results');

  const run = debounce(async (q) => {
    if (!q.trim()) {
      results.classList.remove('lum-open');
      results.innerHTML = '';
      return;
    }
    // Phase 1: searches obras only. As Bíblia da Obra / World Building /
    // Capítulos land in later phases, this same function fans out to
    // those stores too — the dropdown UI doesn't need to change.
    const obras = await obraService.listAll();
    const q_ = q.toLowerCase();
    const matches = obras.filter((o) =>
      o.titulo.toLowerCase().includes(q_) ||
      o.autor.toLowerCase().includes(q_) ||
      (o.tags || []).some((t) => t.toLowerCase().includes(q_))
    ).slice(0, 8);

    if (!matches.length) {
      results.innerHTML = `<div class="lum-header__search-result" style="color:var(--lum-cream-faint)">Nada encontrado.</div>`;
    } else {
      results.innerHTML = matches.map((o) => `
        <div class="lum-header__search-result" data-id="${o.id}">
          ${escapeHtml(o.titulo)}
          <small>Obra · ${escapeHtml(o.autor || 'sem autor')}</small>
        </div>
      `).join('');
    }
    results.classList.add('lum-open');
  }, 200);

  input.addEventListener('input', (e) => run(e.target.value));
  input.addEventListener('blur', () => setTimeout(() => results.classList.remove('lum-open'), 150));

  results.addEventListener('mousedown', (e) => {
    const row = e.target.closest('[data-id]');
    if (!row) return;
    router.navigate(`/dashboard/${row.dataset.id}`);
    input.value = '';
    results.classList.remove('lum-open');
  });
}

