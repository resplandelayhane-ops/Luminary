/* ============================================================
   components/gaveta.js
   ------------------------------------------------------------
   One grid component, four modes. Favoritos/Arquivadas/Lixeira
   are just filtered views of the same obra list — no reason to
   build three separate grids for what is fundamentally the same
   card + the same actions with a different starting filter.
   ============================================================ */

import { obraService } from '../services/obraService.js';
import { router } from '../core/router.js';
import { appState } from '../core/state.js';
import { icon } from '../utils/icons.js';
import { formatNumber, formatRelative, escapeHtml, debounce } from '../utils/helpers.js';
import { confirmDialog } from './modal.js';
import { toast } from '../utils/feedback.js';

const EMPTY_COPY = {
  all: { title: 'Nenhuma obra ainda', body: 'Toda obra começa como um universo em branco. Crie a primeira e comece a construir.', cta: true },
  favoritos: { title: 'Nenhum favorito', body: 'Marque obras com a estrela na Gaveta pra encontrá-las rápido aqui.', cta: false },
  arquivadas: { title: 'Nada arquivado', body: 'Obras pausadas ou concluídas que você arquivar aparecem aqui.', cta: false },
  lixeira: { title: 'Lixeira vazia', body: 'Obras excluídas ficam aqui até você restaurar ou apagar de vez.', cta: false },
};

export async function renderGaveta(container, mode = 'all') {
  appState.set('view', mode === 'all' ? 'gaveta' : mode);

  let allObras = await loadForMode(mode);
  let query = '';
  let sort = 'recentes';

  container.innerHTML = `
    <div class="lum-view">
      <div class="lum-view__header">
        <div>
          <h1 class="lum-view__title">${titleForMode(mode)}</h1>
          <p class="lum-view__subtitle">${subtitleForMode(mode)}</p>
        </div>
        ${mode === 'all' ? `<button class="lum-btn lum-btn--primary" id="lum-btn-nova-obra-2">${icon('plus', { size: 15 })} Nova Obra</button>` : ''}
      </div>
      <div class="lum-shelf-toolbar">
        <div class="lum-field">
          <input type="text" id="lum-shelf-search" placeholder="Buscar nesta estante…" />
        </div>
        <select class="lum-select" id="lum-shelf-sort">
          <option value="recentes">Mais recentes</option>
          <option value="titulo">Título A–Z</option>
          <option value="progresso">Progresso</option>
        </select>
      </div>
      <div id="lum-shelf-grid"></div>
    </div>
  `;

  renderGrid();

  container.querySelector('#lum-shelf-search')?.addEventListener('input', debounce((e) => {
    query = e.target.value.toLowerCase();
    renderGrid();
  }, 150));

  container.querySelector('#lum-shelf-sort')?.addEventListener('change', (e) => {
    sort = e.target.value;
    renderGrid();
  });

  container.querySelector('#lum-btn-nova-obra-2')?.addEventListener('click', () => {
    document.dispatchEvent(new CustomEvent('lum:nova-obra'));
  });

  function visibleList() {
    let list = allObras.filter((o) =>
      !query || o.titulo.toLowerCase().includes(query) || (o.autor || '').toLowerCase().includes(query)
    );
    if (sort === 'titulo') list = [...list].sort((a, b) => a.titulo.localeCompare(b.titulo, 'pt-BR'));
    else if (sort === 'progresso') list = [...list].sort((a, b) => obraService.progress(b) - obraService.progress(a));
    else list = [...list].sort((a, b) => new Date(b.ultimaModificacao) - new Date(a.ultimaModificacao));
    return list;
  }

  function renderGrid() {
    const grid = container.querySelector('#lum-shelf-grid');
    const list = visibleList();
    if (!list.length) {
      const copy = EMPTY_COPY[mode];
      grid.innerHTML = `
        <div class="lum-empty lum-card lum-corners">
          ${icon('books', { size: 40 })}
          <h3>${copy.title}</h3>
          <p>${copy.body}</p>
          ${copy.cta ? `<button class="lum-btn lum-btn--primary" id="lum-empty-cta">${icon('plus', { size: 15 })} Criar primeira obra</button>` : ''}
        </div>
      `;
      grid.querySelector('#lum-empty-cta')?.addEventListener('click', () => document.dispatchEvent(new CustomEvent('lum:nova-obra')));
      return;
    }
    grid.className = 'lum-shelf-grid';
    grid.innerHTML = list.map((o) => bookCard(o, mode)).join('');
    wireCards(grid);
  }

  function wireCards(grid) {
    grid.querySelectorAll('.lum-book').forEach((card) => {
      const id = card.dataset.id;
      card.addEventListener('click', (e) => {
        if (e.target.closest('[data-menu-btn]') || e.target.closest('.lum-menu')) return;
        if (mode === 'lixeira') return;
        router.navigate(`/dashboard/${id}`);
      });
      card.querySelector('[data-fav-btn]')?.addEventListener('click', async (e) => {
        e.stopPropagation();
        await obraService.toggleFavorito(id);
        allObras = await loadForMode(mode);
        renderGrid();
      });
      const menuBtn = card.querySelector('[data-menu-btn]');
      const menu = card.querySelector('.lum-menu');
      menuBtn?.addEventListener('click', (e) => {
        e.stopPropagation();
        document.querySelectorAll('.lum-menu.lum-open').forEach((m) => { if (m !== menu) m.classList.remove('lum-open'); });
        menu.classList.toggle('lum-open');
      });
      menu?.querySelectorAll('[data-action]').forEach((item) => {
        item.addEventListener('click', async (e) => {
          e.stopPropagation();
          menu.classList.remove('lum-open');
          await handleAction(item.dataset.action, id);
        });
      });
    });
    document.addEventListener('click', () => {
      grid.querySelectorAll('.lum-menu.lum-open').forEach((m) => m.classList.remove('lum-open'));
    }, { once: true });
  }

  async function handleAction(action, id) {
    if (action === 'abrir') { router.navigate(`/dashboard/${id}`); return; }
    if (action === 'arquivar') { await obraService.toggleArquivada(id); toast('Status de arquivamento atualizado.'); }
    if (action === 'lixeira') {
      const ok = await confirmDialog({ title: 'Mover para a lixeira?', message: 'A obra some da estante, mas continua recuperável na Lixeira até você excluir de vez.', confirmLabel: 'Mover', danger: true });
      if (!ok) return;
      await obraService.moveToTrash(id);
      toast('Movida para a lixeira.');
    }
    if (action === 'restaurar') { await obraService.restoreFromTrash(id); toast('Obra restaurada.'); }
    if (action === 'excluir-permanente') {
      const ok = await confirmDialog({ title: 'Excluir permanentemente?', message: 'Isso apaga a obra e tudo vinculado a ela para sempre. Não tem como desfazer.', confirmLabel: 'Excluir para sempre', danger: true });
      if (!ok) return;
      await obraService.permanentDelete(id);
      toast('Obra excluída permanentemente.');
    }
    allObras = await loadForMode(mode);
    renderGrid();
  }
}

function bookCard(o, mode) {
  const progress = obraService.progress(o);
  return `
    <div class="lum-book lum-corners" data-id="${o.id}">
      <div class="lum-book__cover">
        ${o.capa ? `<img src="${o.capa}" alt="" />` : ''}
        ${mode !== 'lixeira' ? `<button class="lum-book__fav ${o.favorito ? 'lum-active' : ''}" data-fav-btn aria-label="Favoritar">${icon('star', { size: 13 })}</button>` : ''}
        <span class="lum-book__genre">${escapeHtml(o.genero || 'Sem gênero')}</span>
        <h3 class="lum-book__title">${escapeHtml(o.titulo)}</h3>
        <span class="lum-book__author">${escapeHtml(o.autor || 'Autor não definido')}</span>
      </div>
      <div class="lum-book__meta">
        <span>${formatNumber(o.contadores.capitulos)} cap. · ${formatNumber(o.contadores.palavras)} pal.</span>
        <button class="lum-icon-btn" data-menu-btn style="width:22px;height:22px;" aria-label="Mais ações">${icon('more', { size: 14 })}</button>
      </div>
      <div class="lum-progress"><div class="lum-progress__fill" style="width:${progress}%"></div></div>
      <div style="margin-top:6px;display:flex;justify-content:space-between;align-items:center;">
        <span class="lum-badge lum-badge--${badgeClass(o.status)}">${escapeHtml(o.status)}</span>
        <span style="font-size:10px;color:var(--lum-cream-faint)">${formatRelative(o.ultimaModificacao)}</span>
      </div>
      ${contextMenu(o, mode)}
    </div>
  `;
}

function contextMenu(o, mode) {
  if (mode === 'lixeira') {
    return `
      <div class="lum-menu">
        <div class="lum-menu__item" data-action="restaurar">${icon('restore', { size: 14 })} Restaurar</div>
        <div class="lum-menu__divider"></div>
        <div class="lum-menu__item lum-menu__item--danger" data-action="excluir-permanente">${icon('trash', { size: 14 })} Excluir para sempre</div>
      </div>
    `;
  }
  return `
    <div class="lum-menu">
      <div class="lum-menu__item" data-action="abrir">${icon('dashboard', { size: 14 })} Abrir</div>
      <div class="lum-menu__item" data-action="arquivar">${icon('archive', { size: 14 })} ${o.arquivada ? 'Desarquivar' : 'Arquivar'}</div>
      <div class="lum-menu__divider"></div>
      <div class="lum-menu__item lum-menu__item--danger" data-action="lixeira">${icon('trash', { size: 14 })} Mover para lixeira</div>
    </div>
  `;
}

function badgeClass(status) {
  if (status === 'Planejamento') return 'planning';
  if (status === 'Revisão') return 'review';
  if (status === 'Finalizada') return 'done';
  return '';
}

async function loadForMode(mode) {
  if (mode === 'favoritos') return obraService.listFavoritas();
  if (mode === 'arquivadas') return obraService.listArquivadas();
  if (mode === 'lixeira') return obraService.listLixeira();
  const all = await obraService.listAll();
  return all.filter((o) => !o.arquivada);
}

function titleForMode(mode) {
  return { all: 'Gaveta Literária', favoritos: 'Favoritos', arquivadas: 'Arquivadas', lixeira: 'Lixeira' }[mode];
}
function subtitleForMode(mode) {
  return {
    all: 'Sua estante pessoal. Cada obra é um universo isolado.',
    favoritos: 'As obras que você marcou com estrela.',
    arquivadas: 'Pausadas ou concluídas, fora da estante principal.',
    lixeira: 'Recuperável até você excluir de vez.',
  }[mode];
}
