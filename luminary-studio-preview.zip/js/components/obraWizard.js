/* ============================================================
   components/obraWizard.js
   ============================================================ */

import { obraService } from '../services/obraService.js';
import { openModal } from './modal.js';
import { toast } from '../utils/feedback.js';
import { router } from '../core/router.js';

const STEPS = ['Identidade', 'Forma Narrativa', 'Essência'];

const GENERO_SUGESTOES = ['Fantasia', 'Romance', 'GL (Girls\' Love)', 'Ficção Científica', 'Terror', 'Mistério', 'Drama', 'Aventura', 'Slice of Life'];
const TIPO_NARRATIVA_SUGESTOES = ['Linear', 'Não-linear', 'Multi-POV', 'Epistolar', 'Em arcos'];

export function openNovaObraWizard({ onCreated, onSaved, obra = null } = {}) {
  const isEdit = !!obra;
  let step = 0;
  const data = isEdit ? {
    titulo: obra.titulo, subtitulo: obra.subtitulo, autor: obra.autor, idioma: obra.idioma, status: obra.status,
    genero: obra.genero, subgenero: obra.subgenero, faixaEtaria: obra.faixaEtaria, tipoNarrativa: obra.tipoNarrativa,
    tempoVerbal: obra.tempoVerbal, pessoaNarrativa: obra.pessoaNarrativa,
    sinopse: obra.sinopse, premissa: obra.premissa, objetivo: obra.objetivo,
    capitulosPrevistos: obra.capitulosPrevistos, palavrasPorCapitulo: obra.palavrasPorCapitulo,
  } : {
    titulo: '', subtitulo: '', autor: '', idioma: 'Português (Brasil)', status: 'Planejamento',
    genero: '', subgenero: '', faixaEtaria: 'Livre', tipoNarrativa: '', tempoVerbal: 'Passado', pessoaNarrativa: 'Terceira pessoa limitada',
    sinopse: '', premissa: '', objetivo: '', capitulosPrevistos: '', palavrasPorCapitulo: '',
  };

  const { overlay, close } = openModal({
    title: isEdit ? 'Editar Obra' : 'Nova Obra',
    wide: true,
    bodyHtml: renderStep(),
    footerHtml: renderFooter(),
    onMount: (ov) => wire(ov),
  });

  function renderStep() {
    return `
      <div class="lum-wizard__steps">
        ${STEPS.map((_, i) => `<div class="lum-wizard__step-dot ${i === step ? 'lum-active' : i < step ? 'lum-done' : ''}"></div>`).join('')}
      </div>
      <div class="lum-wizard__step-label">Passo ${step + 1} de ${STEPS.length} · ${STEPS[step]}</div>
      <div id="lum-wizard-fields">${stepFields()}</div>
    `;
  }

  function stepFields() {
    if (step === 0) {
      return `
        <div class="lum-field"><label for="f-titulo">Título *</label><input type="text" id="f-titulo" value="${esc(data.titulo)}" placeholder="Ex: As Crônicas de Luminaris" /></div>
        <div class="lum-field"><label for="f-subtitulo">Subtítulo</label><input type="text" id="f-subtitulo" value="${esc(data.subtitulo)}" /></div>
        <div class="lum-field-row">
          <div class="lum-field"><label for="f-autor">Autor(a)</label><input type="text" id="f-autor" value="${esc(data.autor)}" /></div>
          <div class="lum-field"><label for="f-idioma">Idioma</label>
            <select id="f-idioma">${opts(['Português (Brasil)', 'Português (Portugal)', 'Inglês', 'Espanhol', 'Outro'], data.idioma)}</select>
          </div>
        </div>
        <div class="lum-field"><label for="f-status">Status</label>
          <select id="f-status">${opts(['Planejamento', 'Em Escrita', 'Revisão', 'Finalizada'], data.status)}</select>
        </div>
      `;
    }
    if (step === 1) {
      return `
        <div class="lum-field-row">
          <div class="lum-field"><label for="f-genero">Gênero *</label>
            <input type="text" id="f-genero" list="dl-genero" value="${esc(data.genero)}" placeholder="Ex: Fantasia GL" />
            <datalist id="dl-genero">${GENERO_SUGESTOES.map((g) => `<option value="${g}">`).join('')}</datalist>
          </div>
          <div class="lum-field"><label for="f-subgenero">Subgênero</label><input type="text" id="f-subgenero" value="${esc(data.subgenero)}" /></div>
        </div>
        <div class="lum-field-row">
          <div class="lum-field"><label for="f-faixa">Faixa etária</label>
            <select id="f-faixa">${opts(['Livre', '12+', '14+', '16+', '18+'], data.faixaEtaria)}</select>
          </div>
          <div class="lum-field"><label for="f-tiponar">Tipo de narrativa</label>
            <input type="text" id="f-tiponar" list="dl-tipo" value="${esc(data.tipoNarrativa)}" />
            <datalist id="dl-tipo">${TIPO_NARRATIVA_SUGESTOES.map((g) => `<option value="${g}">`).join('')}</datalist>
          </div>
        </div>
        <div class="lum-field-row">
          <div class="lum-field"><label for="f-tempo">Tempo verbal</label>
            <select id="f-tempo">${opts(['Passado', 'Presente'], data.tempoVerbal)}</select>
          </div>
          <div class="lum-field"><label for="f-pessoa">Pessoa narrativa</label>
            <select id="f-pessoa">${opts(['Primeira pessoa', 'Segunda pessoa', 'Terceira pessoa limitada', 'Terceira pessoa onisciente'], data.pessoaNarrativa)}</select>
          </div>
        </div>
      `;
    }
    return `
      <div class="lum-field"><label for="f-sinopse">Sinopse</label><textarea id="f-sinopse" rows="3">${esc(data.sinopse)}</textarea></div>
      <div class="lum-field"><label for="f-premissa">Premissa</label><textarea id="f-premissa" rows="2">${esc(data.premissa)}</textarea></div>
      <div class="lum-field"><label for="f-objetivo">Objetivo da história</label><textarea id="f-objetivo" rows="2">${esc(data.objetivo)}</textarea></div>
      <div class="lum-field-row">
        <div class="lum-field"><label for="f-capprev">Capítulos previstos</label><input type="number" id="f-capprev" min="0" value="${esc(data.capitulosPrevistos)}" /></div>
        <div class="lum-field"><label for="f-palcap">Palavras por capítulo (média)</label><input type="number" id="f-palcap" min="0" value="${esc(data.palavrasPorCapitulo)}" /></div>
      </div>
    `;
  }

  function renderFooter() {
    return `
      <button class="lum-btn lum-btn--ghost" data-back ${step === 0 ? 'style="visibility:hidden"' : ''}>Voltar</button>
      <button class="lum-btn lum-btn--primary" data-next>${step === STEPS.length - 1 ? (isEdit ? 'Salvar Alterações' : 'Criar Obra') : 'Próximo'}</button>
    `;
  }

  function wire(ov) {
    bindFieldListeners(ov);
    ov.querySelector('[data-back]')?.addEventListener('click', () => { step = Math.max(0, step - 1); rerender(ov); });
    ov.querySelector('[data-next]')?.addEventListener('click', () => handleNext(ov));
  }

  function bindFieldListeners(ov) {
    const map = {
      'f-titulo': 'titulo', 'f-subtitulo': 'subtitulo', 'f-autor': 'autor', 'f-idioma': 'idioma', 'f-status': 'status',
      'f-genero': 'genero', 'f-subgenero': 'subgenero', 'f-faixa': 'faixaEtaria', 'f-tiponar': 'tipoNarrativa',
      'f-tempo': 'tempoVerbal', 'f-pessoa': 'pessoaNarrativa',
      'f-sinopse': 'sinopse', 'f-premissa': 'premissa', 'f-objetivo': 'objetivo',
      'f-capprev': 'capitulosPrevistos', 'f-palcap': 'palavrasPorCapitulo',
    };
    Object.entries(map).forEach(([elId, key]) => {
      const el = ov.querySelector(`#${elId}`);
      if (el) el.addEventListener('input', () => { data[key] = el.value; });
    });
  }

  function rerender(ov) {
    ov.querySelector('.lum-modal__body').innerHTML = renderStep();
    ov.querySelector('.lum-modal__footer').innerHTML = renderFooter();
    wire(ov);
  }

  async function handleNext(ov) {
    if (step === 0 && !data.titulo.trim()) {
      toast('Dê um título pra obra antes de continuar.', { type: 'error' });
      return;
    }
    if (step === 1 && !data.genero.trim()) {
      toast('O gênero é obrigatório — ajuda a IA a calibrar tudo depois.', { type: 'error' });
      return;
    }
    if (step < STEPS.length - 1) {
      step += 1;
      rerender(ov);
      return;
    }
    // Final step: create or update the obra.
    try {
      if (isEdit) {
        const updated = await obraService.update(obra.id, data);
        toast('Alterações salvas.');
        close();
        if (onSaved) onSaved(updated);
      } else {
        const created = await obraService.create(data);
        toast(`"${created.titulo}" criada. Universo em branco, pronto pra escrever.`);
        close();
        if (onCreated) onCreated(created);
        router.navigate(`/dashboard/${created.id}`);
      }
    } catch (err) {
      toast('Não deu pra salvar: ' + err.message, { type: 'error' });
    }
  }
}

function opts(list, selected) {
  return list.map((v) => `<option value="${v}" ${v === selected ? 'selected' : ''}>${v}</option>`).join('');
}

function esc(str) {
  const div = document.createElement('div');
  div.textContent = str ?? '';
  return div.innerHTML;
}
