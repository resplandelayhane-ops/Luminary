/* ============================================================
   components/backup.js
   ------------------------------------------------------------
   Since this ships with zero server (static hosting), "backup"
   means the browser's IndexedDB — which disappears if the user
   clears site data or switches devices. A JSON export/import is
   the honest safety net until cloud sync (if ever) exists.
   ============================================================ */

import { db } from '../core/db.js';
import { appState } from '../core/state.js';
import { toast } from '../utils/feedback.js';
import { icon } from '../utils/icons.js';

const ALL_STORES = ['config', 'obras', 'personagens', 'lugares', 'objetos', 'faccoes', 'capitulos', 'resumos', 'cronologia', 'worldbuilding', 'backups'];

export function renderBackup(container) {
  appState.set('view', 'backup');
  container.innerHTML = `
    <div class="lum-view">
      <div class="lum-view__header">
        <div>
          <h1 class="lum-view__title">Backup</h1>
          <p class="lum-view__subtitle">Seus dados vivem só neste navegador. Exporte de vez em quando.</p>
        </div>
      </div>
      <div class="lum-panel-grid">
        <div class="lum-card lum-corners">
          <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);">Exportar tudo</h3>
          <p style="color:var(--lum-cream-dim);font-size:13.5px;line-height:1.7;margin-bottom:var(--sp-4);">Baixa um arquivo .json com todas as obras e tudo vinculado a elas. Guarde num lugar seguro — esse arquivo é a única cópia fora deste navegador.</p>
          <button class="lum-btn lum-btn--primary" id="lum-export-btn">${icon('save', { size: 15 })} Baixar Backup</button>
        </div>
        <div class="lum-card lum-corners">
          <h3 style="font-family:var(--lum-font-heading);font-size:16px;margin-bottom:var(--sp-3);">Restaurar backup</h3>
          <p style="color:var(--lum-cream-dim);font-size:13.5px;line-height:1.7;margin-bottom:var(--sp-4);">Importa um .json exportado daqui. <strong style="color:var(--lum-red-error);">Substitui</strong> os dados atuais deste navegador — não mescla.</p>
          <input type="file" accept="application/json" id="lum-import-input" style="display:none;" />
          <button class="lum-btn lum-btn--ghost" id="lum-import-btn">Escolher arquivo…</button>
        </div>
      </div>
    </div>
  `;

  container.querySelector('#lum-export-btn').addEventListener('click', exportAll);
  const fileInput = container.querySelector('#lum-import-input');
  container.querySelector('#lum-import-btn').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importAll(file);
  });
}

async function exportAll() {
  try {
    const dump = {};
    for (const store of ALL_STORES) {
      dump[store] = await db.getAll(store);
    }
    const blob = new Blob([JSON.stringify({ version: 1, exportedAt: new Date().toISOString(), stores: dump }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `luminary-studio-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Backup baixado.');
  } catch (err) {
    toast('Falha ao exportar: ' + err.message, { type: 'error' });
  }
}

async function importAll(file) {
  try {
    const text = await file.text();
    const parsed = JSON.parse(text);
    if (!parsed.stores) throw new Error('Arquivo não parece um backup válido.');
    for (const store of ALL_STORES) {
      const records = parsed.stores[store] || [];
      await db.clear(store);
      for (const rec of records) await db.put(store, rec);
    }
    toast('Backup restaurado. Recarregando…');
    setTimeout(() => location.reload(), 1200);
  } catch (err) {
    toast('Falha ao importar: ' + err.message, { type: 'error' });
  }
}
