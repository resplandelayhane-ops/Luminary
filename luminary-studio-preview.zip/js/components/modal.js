/* ============================================================
   components/modal.js — reusable modal shell + confirm dialog
   ============================================================ */

export function openModal({ title, bodyHtml, footerHtml, wide = false, onMount }) {
  const overlay = document.createElement('div');
  overlay.className = 'lum-modal-overlay';
  overlay.innerHTML = `
    <div class="lum-modal ${wide ? 'lum-modal--wide' : ''}" role="dialog" aria-modal="true" aria-label="${escapeAttr(title)}">
      <div class="lum-modal__header">
        <h3 class="lum-modal__title">${title}</h3>
        <button class="lum-icon-btn" data-close aria-label="Fechar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
      </div>
      <div class="lum-modal__body">${bodyHtml}</div>
      ${footerHtml ? `<div class="lum-modal__footer">${footerHtml}</div>` : ''}
    </div>
  `;
  document.body.appendChild(overlay);
  requestAnimationFrame(() => overlay.classList.add('lum-open'));

  function close() {
    overlay.classList.remove('lum-open');
    setTimeout(() => overlay.remove(), 200);
  }

  overlay.addEventListener('mousedown', (e) => { if (e.target === overlay) close(); });
  overlay.querySelector('[data-close]').addEventListener('click', close);
  document.addEventListener('keydown', function onEsc(e) {
    if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onEsc); }
  });

  if (onMount) onMount(overlay, close);
  return { overlay, close };
}

export function confirmDialog({ title, message, confirmLabel = 'Confirmar', danger = false }) {
  return new Promise((resolve) => {
    const { close } = openModal({
      title,
      bodyHtml: `<p style="color:var(--lum-cream-dim);line-height:1.6;font-size:14px;">${message}</p>`,
      footerHtml: `
        <button class="lum-btn lum-btn--ghost" data-cancel>Cancelar</button>
        <button class="lum-btn ${danger ? 'lum-btn--danger' : 'lum-btn--primary'}" data-confirm>${confirmLabel}</button>
      `,
      onMount: (overlay) => {
        overlay.querySelector('[data-cancel]').addEventListener('click', () => { close(); resolve(false); });
        overlay.querySelector('[data-confirm]').addEventListener('click', () => { close(); resolve(true); });
      },
    });
  });
}

function escapeAttr(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}
