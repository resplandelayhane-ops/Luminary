/* ============================================================
   utils/particles.js — ambient gold-dust canvas
   ------------------------------------------------------------
   Performance note: this exists purely for atmosphere, and the
   user works from a phone, so density scales down hard on small
   screens and the whole thing is skipped entirely when the OS
   reports prefers-reduced-motion. A cinematic background is not
   worth a battery drain or a janky scroll on a mid-range phone.
   ============================================================ */

export function mountParticles(canvas, { density = 'normal' } = {}) {
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const ctx = canvas.getContext('2d');
  let particles = [];
  let raf = null;
  let running = true;

  function particleCount() {
    const w = window.innerWidth;
    const base = density === 'low' ? 18 : density === 'landing' ? 55 : 30;
    if (w < 480) return Math.round(base * 0.35);
    if (w < 900) return Math.round(base * 0.6);
    return base;
  }

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = canvas.clientWidth * dpr;
    canvas.height = canvas.clientHeight * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function spawn() {
    const count = particleCount();
    particles = Array.from({ length: count }, () => makeParticle());
  }

  function makeParticle() {
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    return {
      x: Math.random() * w,
      y: Math.random() * h,
      r: 0.6 + Math.random() * 1.6,
      speedY: -(0.06 + Math.random() * 0.16),
      speedX: (Math.random() - 0.5) * 0.06,
      alpha: 0.15 + Math.random() * 0.4,
      flicker: Math.random() * Math.PI * 2,
    };
  }

  function tick() {
    if (!running) return;
    const w = canvas.clientWidth;
    const h = canvas.clientHeight;
    ctx.clearRect(0, 0, w, h);
    particles.forEach((p) => {
      p.y += p.speedY;
      p.x += p.speedX;
      p.flicker += 0.02;
      if (p.y < -5) { p.y = h + 5; p.x = Math.random() * w; }
      const a = p.alpha * (0.6 + 0.4 * Math.sin(p.flicker));
      ctx.beginPath();
      ctx.fillStyle = `rgba(232, 193, 104, ${a.toFixed(3)})`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
    raf = requestAnimationFrame(tick);
  }

  if (reduceMotion) {
    // Draw a single static frame and stop — no animation loop at all.
    resize();
    spawn();
    ctx.clearRect(0, 0, canvas.clientWidth, canvas.clientHeight);
    particles.forEach((p) => {
      ctx.beginPath();
      ctx.fillStyle = `rgba(232, 193, 104, ${p.alpha.toFixed(3)})`;
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fill();
    });
  } else {
    resize();
    spawn();
    tick();
    window.addEventListener('resize', debounceResize);
  }

  let resizeTimer;
  function debounceResize() {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => { resize(); spawn(); }, 200);
  }

  return {
    stop() {
      running = false;
      if (raf) cancelAnimationFrame(raf);
      window.removeEventListener('resize', debounceResize);
    },
  };
}
