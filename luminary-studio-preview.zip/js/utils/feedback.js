/* ============================================================
   utils/feedback.js — toast + forge loader
   ------------------------------------------------------------
   Spec requirement (Part 1): the user must never stare at a
   blank screen or a generic progress bar during AI generation.
   This is the reusable engine for that; the message list is
   swappable per context (chapter generation vs. saga planning
   vs. world building will each pass their own set in Phase 3+).
   ============================================================ */

const DEFAULT_MESSAGES = [
  'Consultando a memória da obra…',
  'Organizando os acontecimentos…',
  'Conectando as linhas narrativas…',
  'As páginas começam a ganhar vida…',
];

export function toast(message, { type = 'info', duration = 3800 } = {}) {
  let stack = document.getElementById('lum-toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.id = 'lum-toast-stack';
    document.body.appendChild(stack);
  }
  const el = document.createElement('div');
  el.className = `lum-toast${type === 'error' ? ' lum-toast--error' : ''}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity 220ms ease, transform 220ms ease';
    el.style.opacity = '0';
    el.style.transform = 'translateX(16px)';
    setTimeout(() => el.remove(), 220);
  }, duration);
}

/**
 * Mounts a rotating-message "forge" loader into `container`.
 * Returns a controller with .stop() to remove it.
 */
export function forgeLoader(container, messages = DEFAULT_MESSAGES) {
  container.innerHTML = `
    <div class="lum-forge">
      <div class="lum-forge__sigil">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.2">
          <path d="M12 2 L14.2 9.2 L21.5 9.2 L15.6 13.6 L17.8 20.8 L12 16.4 L6.2 20.8 L8.4 13.6 L2.5 9.2 L9.8 9.2 Z"/>
        </svg>
      </div>
      <div class="lum-forge__message"></div>
      <div class="lum-forge__bar"><div class="lum-forge__bar-fill"></div></div>
    </div>
  `;
  const msgEl = container.querySelector('.lum-forge__message');
  let i = 0;
  msgEl.textContent = messages[0];
  const interval = setInterval(() => {
    msgEl.classList.add('lum-fade');
    setTimeout(() => {
      i = (i + 1) % messages.length;
      msgEl.textContent = messages[i];
      msgEl.classList.remove('lum-fade');
    }, 180);
  }, 2200);

  return {
    stop() {
      clearInterval(interval);
      container.innerHTML = '';
    },
  };
}
