# Luminary Studio AI — Fase 1

Base do estúdio: landing cinematográfica, shell completo (header + sidebar
responsiva), sistema de obras (criar, editar, favoritar, arquivar, lixeira),
dashboard por obra, backup manual (exportar/importar tudo em .json) e
configurações. Zero backend — roda 100% como site estático.

## Rodar localmente

Não precisa de build. Só precisa servir os arquivos por HTTP (não abrir o
`index.html` direto com `file://`, porque módulos ES e IndexedDB exigem
origem http/https):

```
cd luminary-studio
python3 -m http.server 8080
# abre http://localhost:8080
```

Ou qualquer live-server (VSCode Live Server, `npx serve`, etc.) — não tem
passo de build, é HTML/CSS/JS puro com ES Modules.

## Publicar (GitHub Pages / Cloudflare Pages)

Sobe a pasta inteira como está. Nenhuma configuração de build.

- **GitHub Pages:** Settings → Pages → Deploy from branch → raiz do repo.
- **Cloudflare Pages:** conecta o repo, build command vazio, output
  directory = raiz (`/`).

## O que já funciona

- Landing com partículas (densidade adaptativa por tamanho de tela,
  respeita `prefers-reduced-motion`)
- Header: seletor de provedor de IA + campo de chave (salva só no
  IndexedDB deste navegador, nunca no código), busca global (hoje busca
  só em obras), botão de configurações
- Sidebar recolhível no desktop, drawer no mobile
- Nova Obra (wizard de 3 passos, todos os campos da spec) e Editar Obra
  reaproveitando o mesmo formulário
- Gaveta Literária com busca, ordenação, favoritar, arquivar, lixeira
  (mover/restaurar/excluir permanente)
- Dashboard por obra: estatísticas, progresso, sinopse, objetivo —
  contadores de Personagens/Lugares/Facções já leem do banco (zerados
  até a Fase 2 ter UI pra popular essas tabelas)
- Backup manual: exporta/importa o banco inteiro em `.json`
- Configurações: chaves cadastradas, uso de armazenamento, apagar tudo

## O que ainda não tem UI (Fases seguintes, banco já preparado)

Capítulos, Worldbuilding, Personagens, Cronologia, Biblioteca, Capas, IA
(gerenciador multi-chave completo) — hoje mostram uma tela "Em construção"
honesta em vez de fingir que funcionam. As tabelas do IndexedDB pra tudo
isso (`personagens`, `lugares`, `objetos`, `faccoes`, `capitulos`,
`resumos`, `cronologia`, `worldbuilding`, `backups`) **já existem no
schema** (`js/core/db.js`) — quando essas telas forem construídas, não
tem migração de banco quebrando dado de cliente que já estiver usando o
site.

## Decisões de arquitetura já fixadas (não perguntar de novo)

- **IndexedDB**, não localStorage, pra capítulos/bíblia/backups —
  localStorage estoura ~5-10MB numa obra de 40 capítulos com histórico
  de versões. localStorage só guarda config leve (nada disso ainda
  existe além das chaves de API).
- **Contexto curado por capítulo** — quando o Gerador de Capítulos for
  construído, o prompt pra IA não vai levar a bíblia inteira: só os
  personagens/lugares selecionados + resumo dos últimos capítulos.
- **Uma chamada de IA por capítulo pra extrair o que mudou** — não N
  chamadas por personagem/lugar/objeto.

## Estrutura de arquivos

```
index.html
css/
  tokens.css        → paleta, fontes, espaçamento (única fonte da verdade visual)
  base.css          → reset + utilitários (linha dourada, cantos ornamentais)
  landing.css
  layout.css        → header, sidebar, shell, responsivo
  components.css    → cards, formulários, modais, wizard, estante
  animations.css     → forja de carregamento, partículas
js/
  core/
    db.js            → wrapper do IndexedDB + schema completo
    state.js         → estado global (obra ativa, sidebar) via pub/sub
    router.js         → roteador por hash
  services/
    obraService.js    → único ponto de leitura/escrita da tabela 'obras'
  components/
    landing.js, header.js, sidebar.js, gaveta.js, dashboard.js,
    obraWizard.js, modal.js, backup.js, configuracoes.js, placeholder.js
  utils/
    helpers.js, icons.js, feedback.js (toast + forja), particles.js
  main.js             → o único arquivo que conecta tudo
```

Próxima fase: me manda qual módulo quer primeiro (Gerador de Capítulos é
o mais importante segundo a spec, mas Personagens/Worldbuilding também
dá pra ir na frente se preferir escrever a bíblia antes de gerar texto).
